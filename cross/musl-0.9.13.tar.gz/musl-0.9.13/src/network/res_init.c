int res_init()
{
	return 0;
}
