#include <netinet/in.h>

const struct in6_addr in6addr_any = IN6ADDR_ANY_INIT;
