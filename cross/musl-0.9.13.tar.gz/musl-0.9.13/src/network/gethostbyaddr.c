#define _GNU_SOURCE

#include <netdb.h>
#include <string.h>
#include <netinet/in.h>
#include <errno.h>
#include <stdlib.h>

struct hostent *gethostbyaddr(const void *a, socklen_t l, int af)
{
	static struct hostent *h;
	size_t size = 63;
	struct hostent *res;
	int err;
	do {
		free(h);
		h = malloc(size+=size+1);
		if (!h) {
			h_errno = NO_RECOVERY;
			return 0;
		}
		err = gethostbyaddr_r(a, l, af, h,
			(void *)(h+1), size-sizeof *h, &res, &h_errno);
	} while (err == ERANGE);
	return err ? 0 : h;
}
