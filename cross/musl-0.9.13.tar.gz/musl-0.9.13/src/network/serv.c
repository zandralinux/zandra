#include <netdb.h>
#include <stdio.h>
#include <string.h>

void endservent(void)
{
}

void setservent(int stayopen)
{
}

struct servent *getservent(void)
{
	return 0;
}
